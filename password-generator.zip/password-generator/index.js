#!/usr/bin/env node

// Basic CLI Boilerplate setup
const argv = require('yargs/yargs')(process.argv.slice(2))
    .usage('Usage: $0 --length [num] --numbers --uppercase --symbols')
    .help('h')
    .alias('h', 'help')
    .argv;

// Password generation function, using Math + random to make a unique password
const generatePassword = (length, useNums, useUpCase, useSymbols) => {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const symbols = '!@#$%^&*()_+{}:"<>?|[];,./';

    let chars = lowercase;

    if (useNums) chars += numbers;
    if (useUpCase) chars += uppercase;
    if (useSymbols) chars += symbols;

    let password = '';
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return password;
}

// User input section
const length = argv.length ? parseInt(argv.length) : 8; // Ensures that default length is 8 digits
const useNums = argv.numbers || false;
const useUpCase = argv.uppercase || false;
const useSymbols = argv.symbols || false;

const password = generatePassword(length, useNums, useUpCase, useSymbols);
console.log(`Good luck remembering this: ${password}`);