Hi! 

Welcome to the password-generator,

This project is based on creating a CLI application using Node.js to generate passwords for users based on arguments via flags.
To try it out, simply enter the bin command in package.json to run the app and give it a whirl! You may find out a password to use 
for one of your accounts.

INSTRUCTIONS:

-run program in terminal, navigate to inside password-generator folder "cd password-generator"
-use "npx index.js" to generate a random password with a default of 8 letters
-to add extras, you can use the following commands (--length, --uppercase, --symbols, --numbers) to make a longer password, include capitals, use !@#$% or extra numbers!
-profit

As part of my third semester, this is the first QAP due for the Fullstack Javascript course. 

Thanks,
Cameron Beanland

09/19/2024